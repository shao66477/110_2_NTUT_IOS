//
//  ViewController.swift
//  MidtermProject_Calculator
//
//  Created by 賴昱劭 on 2022/4/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var formulaLabel: UILabel!
    var formula: String = "" {
        didSet {
            formulaLabel.text = formula
        }
    }
    @IBOutlet weak var numLabel: UILabel!
    var num: String = "0" {
        didSet {
            numLabel.text = num
        }
    }
    
    var num_Flag = true
    @IBAction func number(_ sender: UIButton) {
        if(cal_Flag == true) {
            equation = []
            formula = ""
            cal_Flag = false
        }
        let inputNumber = sender.tag - 1
        if(num == "0" || num_Flag == false) {
            /*
            if(inputNumber != 0) {
                num = String(inputNumber)
                num_Flag = true
                clear_Flag = true
            }
            */
            num = String(inputNumber)
            num_Flag = true
            clear_Flag = true
        }
        else if(num == "-0") {
            if(inputNumber != 0) {
                num = "-"
                num += String(inputNumber)
                num_Flag = true
                clear_Flag = true
            }
        }
        else {
            num += String(inputNumber)
            num_Flag = true
        }
        updateButton()
        updateViewFromModel()
    }
    
    var dot_Flag = false
    @IBAction func floatDot(_ sender: UIButton) {
        if(dot_Flag == false) {
            if(cal_Flag == true) {
                equation = []
                formula = ""
                cal_Flag = false
            }
            if(num_Flag == false) {
                num = "0"
            }
            num += "."
            dot_Flag = true
            clear_Flag = true
            num_Flag = true
        }
        updateButton()
        updateViewFromModel()
    }
    
    var neg_Flag = false
    @IBAction func negORpos(_ sender: UIButton) {
        if(neg_Flag == false) {
            num.insert("-", at: num.startIndex)
            neg_Flag = true
        }
        else if(neg_Flag == true) {
            num.remove(at: num.startIndex)
            neg_Flag = false
        }
    }
    
    @IBOutlet var clearButton: [UIButton]!
    var clear_Flag = false
    @IBAction func clear(_ sender: UIButton) {
        if(sender.titleLabel!.text == "AC") {
            equation.removeAll()
            formula = ""
            num = "0"
            num_Flag = true
            clear_Flag = false
            dot_Flag = false
            neg_Flag = false
        }
        else {
            clear_Flag = false
            num = "0"
            num_Flag = equation.isEmpty ? true : false
            dot_Flag = false
            neg_Flag = false
        }
        
        updateViewFromModel()
        updateButton()
        showEquation()
    }
    
    @IBAction func percentage(_ sender: UIButton) {
        if(num != "0") {
            if(dot_Flag == false) {
                if(num.count < 3) {
                    while(num.count < 3) {
                        num.insert("0", at: num.startIndex)
                    }
                }
                let dot_Index = num.index(num.endIndex, offsetBy: -2)
                num.insert(".", at: dot_Index)
                dot_Flag = true
                //updateViewFromModel()
            }
            else {
                var dot_Index = num.firstIndex(of: ".")
                var distance = num.distance(from: num.startIndex, to: dot_Index!)
                while(distance < 3) {
                    //print(distance)
                    num.insert("0", at: num.startIndex)
                    dot_Index = num.firstIndex(of: ".")
                    distance = num.distance(from: num.startIndex, to: dot_Index!)
                }
                dot_Index = num.firstIndex(of: ".")
                num.remove(at: dot_Index!)
                dot_Index = num.index(after: num.startIndex)
                num.insert(".", at: dot_Index!)
            }
        }
    }
    
    @IBOutlet var operations: [UIButton]!
    func updateViewFromModel() {
        //let tmp = "÷"
        if(equation.isEmpty || num_Flag == true) {
            for index in operations.indices {
                let op = operations[index]
                op.backgroundColor = #colorLiteral(red: 0.1997963786, green: 0.5086628795, blue: 0.7198596001, alpha: 1)
                op.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: UIControl.State.normal)
            }
        }
        else {
            let tmp = equation[equation.count - 1]
            for index in operations.indices {
                let op = operations[index]
                //print(op.cu)
                if(op.titleLabel!.text == tmp) {
                    op.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                    op.setTitleColor(#colorLiteral(red: 0.1997963786, green: 0.5086628795, blue: 0.7198596001, alpha: 1), for: UIControl.State.normal)
                    //#colorLiteral(red: 0.1997963786, green: 0.5086628795, blue: 0.7198596001, alpha: 1)
                }
                else {
                    op.backgroundColor = #colorLiteral(red: 0.1997963786, green: 0.5086628795, blue: 0.7198596001, alpha: 1)
                    op.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: UIControl.State.normal)
                }
            }
        }
    }
    
    func updateButton() {
        for index in clearButton.indices {
            let bt = clearButton[index]
            if(clear_Flag == true) {
                bt.setTitle("C", for: UIControl.State.normal)
            }
            else {
                bt.setTitle("AC", for: UIControl.State.normal)
            }
        }
    }
    
    func showEquation() {
        formula = ""
        for e in equation {
            formula += e
            formula += " "
        }
                    
    }
    
    let operationSym = ["+", "-", "×", "÷"]
    var equation = Array<String>()
    @IBAction func operation(_ sender: UIButton) {
        if(cal_Flag == true) {
            equation = []
            formula = ""
            cal_Flag = false
            num_Flag = true
        }
        if(num_Flag == true) {
            if(dot_Flag == true) {
                var end_Index = num.index(before: num.endIndex)
                while(num[end_Index] == "0") {
                    num.remove(at: end_Index)
                    end_Index = num.index(before: num.endIndex)
                }
                end_Index = num.index(before: num.endIndex)
                if(num[end_Index] == ".") {
                    num.remove(at: end_Index)
                }
            }
            equation.append(num)
            num_Flag = false
            dot_Flag = false
        }
        else {
            if(!equation.isEmpty && operationSym.contains(equation[equation.count - 1])) {
                equation.remove(at: equation.count - 1)
                num = equation[equation.count - 1]
            }
        }
        let c = sender.tag
        switch c {
        case 11:
            equation.append("+")
        case 12:
            equation.append("-")
        case 13:
            equation.append("×")
        case 14:
            equation.append("÷")
        default:
            break
        }
        
        updateViewFromModel()
        showEquation()
    }
    
    var low = ["+", "-"]
    var high = ["×", "÷"]
    func piority(i: String, s: String) -> Int {
        var ic: Int = -1
        var sc: Int = -1
        var R: Int = 0
        if s == "=" {
            return 3
        }
        
        if(high.contains(i)) {
            ic = 1
        }
        else if(low.contains(i)) {
            ic = 0
        }
        if(high.contains(s)) {
            sc = 1
        }
        else if(low.contains(s)) {
            sc = 0
        }
                        
        if(ic > sc) {
            R = 1
        }
        else {
            R = 2
        }
        return R
    }
    
    var cal_Flag = false
    @IBAction func calculate(_ sender: UIButton) {
        if(!equation.isEmpty) {
            //num = "0"
            if(dot_Flag == true) {
                var end_Index = num.index(before: num.endIndex)
                while(num[end_Index] == "0") {
                    num.remove(at: end_Index)
                    end_Index = num.index(before: num.endIndex)
                }
                end_Index = num.index(before: num.endIndex)
                if(num[end_Index] == ".") {
                    num.remove(at: end_Index)
                }
            }
            equation.append(num)
            equation.append("=")
            num_Flag = false
            dot_Flag = false
            updateViewFromModel()
            showEquation()
            
            //print(equation)
            
            var stack: Array<String> = ["="]
            var postfix: Array<String> = Array()
            
            for e in equation {
                //print(e)
                if(e == "=") {
                    //print(stack)
                    while (stack[stack.count-1] != "=") {
                        postfix.append(stack[stack.count-1])
                        stack.remove(at: stack.count-1)
                    }
                }
                else if(operationSym.contains(e)) {
                    while (piority(i: e, s: stack[stack.count-1]) == 2) {
                        postfix.append(stack[stack.count-1])
                        stack.remove(at: stack.count-1)
                    }
                    stack.append(e)
                    //print(stack)
                    
                }
                else {
                    postfix.append(e)
                }
            }
            //print(postfix)
            //a + b * d + c / d
            //1 + 2 * 4 + 3 / 4
            
            //a b d * + c d / +
            //1 2 4 * + 3 4 / +
            
            stack = []
            var ans_Buffer: Float = 0
            for e in postfix {
                if(operationSym.contains(e)) {
                    print(e)
                    switch e {
                    case "+":
                        ans_Buffer = Float(stack[stack.count - 2])! + Float(stack[stack.count - 1])!
                        stack.remove(at: stack.count - 2)
                        stack.remove(at: stack.count - 1)
                        stack.append(String(ans_Buffer))
                    case "-":
                        ans_Buffer = Float(stack[stack.count - 2])! - Float(stack[stack.count - 1])!
                        stack.remove(at: stack.count - 2)
                        stack.remove(at: stack.count - 1)
                        stack.append(String(ans_Buffer))
                    case "×":
                        ans_Buffer = Float(stack[stack.count - 2])! * Float(stack[stack.count - 1])!
                        stack.remove(at: stack.count - 2)
                        stack.remove(at: stack.count - 1)
                        stack.append(String(ans_Buffer))
                    case "÷":
                        if(Float(stack[stack.count - 1])! == 0) {
                            ans_Buffer = 0
                        }
                        else {
                            ans_Buffer = Float(stack[stack.count - 2])! / Float(stack[stack.count - 1])!
                            stack.remove(at: stack.count - 2)
                            stack.remove(at: stack.count - 1)
                        }
                        stack.append(String(ans_Buffer))
                    default:
                        break
                    }
                }
                else {
                    stack.append(e)
                }
            }
            var ans = String(ans_Buffer)
            var end_Index = ans.index(before: ans.endIndex)
            while(ans[end_Index] == "0") {
                ans.remove(at: end_Index)
                end_Index = ans.index(before: ans.endIndex)
            }
            end_Index = ans.index(before: ans.endIndex)
            if(ans[end_Index] == ".") {
                ans.remove(at: end_Index)
            }
            //ansLabel.text = String(tempAns)
            num = ans
            cal_Flag = true
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

