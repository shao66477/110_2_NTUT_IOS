//
//  ViewController.swift
//  BMI Calculator
//
//  Created by 賴昱劭 on 2022/3/7.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var height: UITextField!
    @IBOutlet weak var weight: UITextField!
    @IBOutlet weak var bmi: UILabel!
    @IBOutlet weak var segControl: UISegmentedControl!
    @IBOutlet weak var status: UILabel!
    
    //let hei: Int = height.text!
    @IBAction func Calculate(_ sender: UIButton) {
        var text1: Float? = Float(height.text!)
        var text2: Float? = Float(weight.text!)
        
        var num: Float = text1!/100
        var num1: Float = num * num
        var num2: Float = text2!
        var B: Float = num2/num1
        bmi.text = String(B)
        var genFlag: Int = -1
        switch segControl.selectedSegmentIndex
        {
        case 0:
            genFlag = 0
        case 1:
            genFlag = 1
        default:
            break
        }
        if genFlag == 0 {
            //status.text = "Male"
            if B < 18.5 {
                status.text = "Underweight"
            }else if B > 18.5 && B < 24.9 {
                status.text = "Healthy Weight"
            }else if B > 25 && B < 29.9 {
                status.text = "Over Weight"
            }else if B > 29.9 {
                status.text = "Obesity"
            }
        }else {
            //status.text = "Female"
            if B < 18.5 {
                status.text = "Underweight"
            }else if B > 18.5 && B < 24.9 {
                status.text = "Healthy Weight"
            }else if B > 25 && B < 29.9 {
                status.text = "It's a secret"
            }else if B > 29.9 {
                status.text = "It's a secre"
            }
        }
        //var num1: Int = text1! * text1!
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

